import java.util.Scanner;
import java.util.concurrent.TimeUnit;
/**
 * Write a description of class Game here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Game
{
    private int score;
    private int random;
    private int correct;
    private int rightAnswer;
    private int numOfStrikesLeft;
    Scanner input = new Scanner(System.in);
    /**
     * Constructor for objects of class Game
     */
    public Game()
    {
        // initialise instance variables
        score = 0;
        System.out.println("Would you like to play State Trivia?");
        System.out.println("Press 'y' to begin");
        
        String output = input.next();
        if (output.equalsIgnoreCase("y"))
        {
            System.out.println("Easy? Medium? or Hard?");
            output = input.next();
            if(output.equalsIgnoreCase("easy"))
            {
                numOfStrikesLeft = 20;
            }
            else if (output.equalsIgnoreCase("medium"))
            {
                numOfStrikesLeft = 10;
            }
            else
            {
                numOfStrikesLeft = 3;
            }
            
            //Create a new game of State Questions
            StateQuestion play = new StateQuestion();
            
            //Get the Question and print it out for the player
            String StateQuestion = play.getStateQuestion();
            System.out.println(StateQuestion);
            
            

            //Get the Correct answer and two fake answers
            String StateAnswer = play.getStateAnswer();
            String StateFakeAnswer1 = play.getStateAnswerFake1();
            String StateFakeAnswer2 = play.getStateAnswerFake2();
                                   
            //Changes the order of the answers
            random = 0 + (int)(Math.random() * ((2 - 0) + 1));
            if (random == 0)
            {
                System.out.println("1.)" + StateAnswer);
                System.out.println("2.)" + StateFakeAnswer1);
                System.out.println("3.)" + StateFakeAnswer2);
                rightAnswer = 1;
            }
            else if (random == 1)
            {
                System.out.println("1.)" + StateFakeAnswer1);
                System.out.println("2.)" + StateAnswer);
                System.out.println("3.)" + StateFakeAnswer2);
                rightAnswer = 2;
            }
            else 
            {
                System.out.println("1.)" + StateFakeAnswer2);
                System.out.println("2.)" + StateFakeAnswer1);
                System.out.println("3.)" + StateAnswer);
                rightAnswer = 3;
            }
            int next = input.nextInt();
            if (next == rightAnswer)
            {
                 System.out.println("You are correct!");
                 score = score + 1;
                 
            }
            else
            {
                System.out.println("Wrong!");
                System.out.println("You have " + numOfStrikesLeft + " strikes left");
                
            }
            
            
       
            
            
        }
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return y;
    }
}
