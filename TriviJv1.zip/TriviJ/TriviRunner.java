import java.util.Scanner;
/**
 * Write a description of class TriviRunner here.
 *
 * @Wade Costa
 * @v1
 */
public class TriviRunner
{
    public static void main (String [] args)
    {
        String output;
        Scanner input = new Scanner(System.in);
        do{
            System.out.println("------------------");
            System.out.println("");
            System.out.println("Welcome to TriviJ");
            System.out.println("");
            System.out.println("------------------");
            System.out.println("Would you like to play?");
            System.out.println("Press 'y' to begin");
        
            output = input.next();
        } while (!output.equalsIgnoreCase("y"));
        if (output.equalsIgnoreCase("y"))
        {
            Game startSQ = new Game();
        }
        
    }
}
